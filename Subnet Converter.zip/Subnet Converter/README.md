# Number-System-Converter
This is a beginner friendly project (An application which is used to convert the given input in a specified number system to another number system of choice), for learning how to work on github.

# Languages/Frameworks Used
* Python 3.x
* Tkinter (Available by default upon python installation)
